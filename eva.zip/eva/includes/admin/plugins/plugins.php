<?php
require EVA_THEME_PATH .'/includes/admin/plugins/class-tgm-plugin-activation.php';

function eva_theme_register_required_plugins() {

  $plugins = array(

    // Include plugins pre-packaged with the theme

    array(
			'name'               => esc_html__('Eva Theme Extensions', 'eva'),
			'slug'               => 'tdl-extensions',
			'source'             => 'https://temashdesign.me/themeforest/plugins/eva/1.9.9.84/tdl-extensions.zip',
			'required'           => true,
			'version'            => '2.3',
			'force_activation'   => false,
			'force_deactivation' => false,
			'external_url'       => ''
		),


    array(
			'name'               => esc_html__('WPBakery Visual Composer', 'eva'),
			'slug'               => 'js_composer',
			'source'             => 'https://temashdesign.me/themeforest/plugins/eva/1.9.9.89/js_composer.zip',
			'required'           => false,
			'version'            => '7.0',
			'force_activation'   => false,
			'force_deactivation' => false,
			'external_url'       => ''
		),

    array(
			'name'               => esc_html__('Slider Revolution', 'eva'),
			'slug'               => 'revslider',
			'source'             => 'https://temashdesign.me/themeforest/plugins/eva/1.9.9.89/revslider.zip',
			'required'           => false,
			'version'            => '6.6.15',
			'force_activation'   => false,
			'force_deactivation' => false,
			'external_url'       => ''
		),

    array(
			'name'               => esc_html__('WooCommerce Search Engine', 'eva'),
			'slug'               => 'woo-search-box',
			'source'             => 'https://temashdesign.me/themeforest/plugins/eva/1.9.9.88/woo-search-box.zip',
			'required'           => false,
			'version'            => '2.2.16',
			'force_activation'   => false,
			'force_deactivation' => false,
			'external_url'       => ''
		),

		array(
			'name'               => esc_html__('Envato Market (theme updates)', 'eva'),
			'slug'               => 'envato-market',
			'source'             => 'https://envato.github.io/wp-envato-market/dist/envato-market.zip',
			'required'           => false,
			'version'            => '2.0.7',
			'force_activation'   => false,
			'force_deactivation' => false,
			'external_url'       => ''
		),



    // Include plugins from the WordPress Plugin Repository

    array(
			'name'               => esc_html__('Redux Framework', 'eva'),
			'slug'               => 'redux-framework',
			'required'           => true,
			'force_activation'   => false,
			'force_deactivation' => false,
		),

    array(
			'name'               => esc_html__('Advanced Custom Fields', 'eva'),
			'slug'               => 'advanced-custom-fields',
			'required'           => true,
			'force_activation'   => false,
			'force_deactivation' => false,
		),

    array(
			'name'               => esc_html__('WooCommerce', 'eva'),
			'slug'               => 'woocommerce',
			'required'           => false,
			'force_activation'   => false,
			'force_deactivation' => false,
		),

		array(
			'name'               => esc_html__('WCBoost - Variation Swatches', 'eva'),
			'slug'               => 'wcboost-variation-swatches',
			'required'           => false,
			'force_activation'   => false,
			'force_deactivation' => false,
		),

    array(
			'name'               => esc_html__('Contact Form 7', 'eva'),
			'slug'               => 'contact-form-7',
			'required'           => false,
			'force_activation'   => false,
			'force_deactivation' => false,
		),


    array(
			'name'               => esc_html__('Breadcrumb NavXT', 'eva'),
			'slug'               => 'breadcrumb-navxt',
			'required'           => false,
			'force_activation'   => false,
			'force_deactivation' => false,
		),


    array(
			'name'               => esc_html__('Safe SVG', 'eva'),
			'slug'               => 'safe-svg',
			'required'           => false,
			'force_activation'   => false,
			'force_deactivation' => false,
		),

    array(
			'name'               => esc_html__('Smash Balloon Instagram Feed', 'eva'),
			'slug'               => 'instagram-feed',
			'required'           => false,
			'force_activation'   => false,
			'force_deactivation' => false,
		),

		array(
			'name'               => esc_html__('YITH WooCommerce Wishlist', 'eva'),
			'slug'               => 'yith-woocommerce-wishlist',
			'required'           => false,
			'force_activation'   => false,
			'force_deactivation' => false,
		),

  );

  $config = array(
		'id'           => 'eva',
		'default_path' => '',                          // Default absolute path to pre-packaged plugins
		'parent_slug'  => 'themes.php',
		'menu'         => 'install-required-plugins',  // Menu slug
		'has_notices'  => true,                        // Show admin notices or not
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => true,                   // Automatically activate plugins after installation or not.
		'message'      => '<div class="notice-warning notice"><p>Install the following required or recommended plugins to get complete functionality from your new theme.</p></div>',                      // Message to output right before the plugins table.
		'strings'      => array(
		'return'       => esc_html__( 'Return to Theme Plugins', 'eva' )
		)
	);

  tgmpa( $plugins, $config );
}

add_action( 'tgmpa_register', 'eva_theme_register_required_plugins' );